# q1
# def power(base, exponent):
#     if exponent == 0:
#         return 1
#     if exponent >= 1:
#         return base * power(base, exponent - 1)
#
#     return f"1 / {power(base, -exponent)}"  # Handle negative exponents
#
# x = power(2, -3)
# print(x)

# q2
# def gcd(x, y):
#     if y == 0:
#         return x
#
#     return gcd(y, x % y)
#
# print(gcd(10,2))

# q3

# def print_increasing_numbers(n):
#     def build_number(pos, last_digit, num):
#         if pos > n:
#             print(num)
#             return
#
#         for digit in range(last_digit + 1, 10):
#             build_number(pos + 1, digit, num + str(digit))
#
#     build_number(1, 0, "")
#
#
# print("2-digit strictly increasing numbers:")
# print_increasing_numbers(2)

# q4
# 1 1 2 3 5 8
def fibonacii(n, p1 = 1, p2 = 1):
    if n == 2:
        return

    temp = p2
    p2 = p2 + p1
    p1 = temp

    print(p2)

    fibonacii(n - 1, p1, p2)

print(1)
print(1)
# fibonacii(7)

# loop in recursion
# def x(i):
#
#     if i == 2:
#         return
#
#     print(i)
#     x(i-1)
# x(7)

# q5

x = [5,4,3,2,1]
def quicksort(arr, low, high):
    if low >= high:
        return

    mid = low + (high - low) // 2
    pivot = arr[mid]
    start = low
    end = high

    while start <= end:
        # Find element on left that should be on right
        while arr[start] < pivot:
            start += 1
        # Find element on right that should be on left
        while arr[end] > pivot:
            end -= 1

        # Swap elements and move indices
        if start <= end:
            arr[start], arr[end] = arr[end], arr[start]
            start += 1
            end -= 1

    # Recursive calls for subarrays
    quicksort(arr, low, end)
    quicksort(arr, start, high)

def merge(left, right):
    newArr = []
    i = 0
    j = 0

    while i < len(left) and j < len(right):
        if left[i] < right[j]:
            newArr.append(left[i])
            i += 1
        else:
            newArr.append(right[j])
            j += 1

    while i < len(left):
        newArr.append(left[i])
        i += 1

    while j < len(right):
        newArr.append(right[j])
        j += 1

    return newArr

def mergeSort(arr):
    if len(arr) <= 1:
        return arr

    m = len(arr) // 2

    leftCopy = arr[:m]
    rightCopy = arr[m:]

    left = mergeSort(leftCopy)
    right = mergeSort(rightCopy)

    return merge(left, right)


def selectionSort(arr):
    for i in range(len(arr)):
        lastIndex = len(arr) - i - 1
        maxIndex = arr.index(max(arr[:lastIndex+1]))
        arr[maxIndex], arr[lastIndex] = arr[lastIndex], arr[maxIndex]

def insertionSort(arr):
    for i in range(1, len(arr)):
        for j in range(i -1, -1,-1):
            if(arr[j] > arr[i]):
                arr[j], arr[i] = arr[i], arr[j]


if __name__ == "__main__":
    arr = [64, 34, 25, 12, 22, 11, 90]
    # sorted_arr = mergeSort(arr)
    # print("Sorted array:", sorted_arr)
    # y =sorted_arr.index(max(sorted_arr))
    # print(y)
    # selectionSort(arr)
    # print(arr)
    if('apple' < 'orange'):
        print("ss")


