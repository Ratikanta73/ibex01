import random


class Card:
    def __init__(self, type, value):
        self.type = type
        self.value = value

    def __str__(self):
        return f"{self.type}{self.value}"

class Deck:
    def __init__(self):
        cardTypes = ['Hearts', 'Diamonds', 'Clubs', 'Spades']
        cardValues = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A']
        self.cards = [Card(type, value) for type in cardTypes for value in cardValues]

    def shuffle(self):
        random.shuffle(self.cards)

    def deal(self, n):
        return [self.cards.pop() for _ in range(n)]

class Player:
    def __init__(self, name):
        self.name = name
        self.hand = []

    def recieveCards(self, cards):
        self.hand = cards

    def showCards(self):
        print(f"{self.name}'s")
        for card in self.hand:
            print(card, end=", ")
        print()

d1 = Deck()

d1.shuffle()

bob = Player("Bob")
john = Player("john")

bob.recieveCards(d1.deal(5))
john.recieveCards(d1.deal(5))

bob.showCards()
john.showCards()