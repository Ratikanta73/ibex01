from textblob import TextBlob
exercise_blob = TextBlob("This is a TextBlob")
print(exercise_blob)